# ECMM447 - Reddit Community Detection

**IMPORTANT**: The code in this repository was created solely for a report, which can be found [here](./docs/ECMM447___Report.pdf).

Although I have provided the Notebook as a PDF, as required, some of the images generated using Datashader do not display correctly 
as part of a PDF, so please do try to run the Notebook. The files found in the [data folder](./data) are provided so that formatting is 
kept the same during execution.